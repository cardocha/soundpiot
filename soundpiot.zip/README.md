# Soundpiot
A Simple Player addon for Firefox

![alt text](https://raw.githubusercontent.com/cardocha/soundpiot/master/screenshot.png)


## Firefox Addon Page
https://addons.mozilla.org/en-US/firefox/addon/soundpiot/

## Getting Started
Edit the source from any text editor, is just html, css and plain js.

### Prerequisites

None

## Authors

Luciano Cardoso https://github.com/cardocha

## License

This project is licensed under the Apache 2 License - see the https://apache.org/licenses/LICENSE-2.0 file for details
